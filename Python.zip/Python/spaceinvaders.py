from typing import Any
import pygame as pg
from pygame.locals import *
from pygame.sprite import AbstractGroup
import random
import time



WIDTH, HEIGHT = 400, 600   # lenge og bredden av skjermen
FPS = 24 # Frame per second. 

class Fly(pg.sprite.Sprite):
    def __init__(self) -> None:
        super().__init__()
        self.image = pg.Surface((50,50))
        self.rect = self.image.get_rect()
        self.image.fill("white")
        pg.draw.circle(self.image, "yellow", (25,25),25)
        self.rect.x = (WIDTH-self.rect.width)/2
        self.rect.y = HEIGHT-(HEIGHT-self.rect.height)/4
        self.fart_x = 5

    
    def update(self):
        keys = pg.key.get_pressed()
        if keys[pg.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.fart_x
            PewPewFly.posisjon_x = self.rect.x + 25

        if keys[pg.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.fart_x
            PewPewFly.posisjon_x = self.rect.x + 25
            

        
class PewPewFly(pg.sprite.Sprite):
    posisjon_x = 175 + 25
    def __init__(self,fart) -> None:
        super().__init__()
        self.image = pg.Surface((3,8))
        self.rect = self.image.get_rect()
        self.image.fill("red")
        self.rect.x = PewPewFly.posisjon_x
        self.rect.y = HEIGHT-(HEIGHT-self.rect.height)/4
        self.fart_y = fart
    
    def update(self) -> None:
        if self.rect.top < 0:
            self.kill()
        else:
            self.rect.y -= self.fart_y

class Aliens(pg.sprite.Sprite):
    fart_x = 1
    fart_y = 6
    sjanse = 500
    def __init__(self,x,y) -> None:
        super().__init__()
        self.image = pg.Surface((20,20))
        self.rect = self.image.get_rect()
        self.image.fill("blue")
        self.rect.x = x
        self.rect.y = y


    def update(self) -> None:
        if random.randint(1,Aliens.sjanse) == 10:
              app.alienskyt(self.rect.x,self.rect.y)
                     
        if self.rect.x > WIDTH-20 and Aliens.fart_x > 0:
            Aliens.fart_x *= -1

            for i in app.aliens:
                i.rect.y += Aliens.fart_y
         
        elif self.rect.x < 0 and self.fart_x < 0:
            Aliens.fart_x *= -1

            for i in app.aliens:
                i.rect.y += Aliens.fart_y

        
        self.rect.x += Aliens.fart_x

            
class AliensPewPew(pg.sprite.Sprite):
    def __init__(self,x,y) -> None:
        super().__init__()
        self.image = pg.Surface((3,8))
        self.rect = self.image.get_rect()
        self.image.fill("blue")
        self.rect.x = x
        self.rect.y = y
        self.fart = 6
        
    def update(self) -> None:
        self.rect.y += self.fart


class Shield(pg.sprite.Sprite):
    def __init__(self,x,y) -> None:
        super().__init__()
        self.image = pg.Surface((6,6))
        self.rect = self.image.get_rect()
        self.image.fill("green")
        self.rect.x = x
        self.rect.y = y


class App:
    def __init__(self):
        pg.init()  #Pygame blir initialisert
        self.clock = pg.time.Clock() #Den klokken trenger jeg for FPS
        self.screen = pg.display.set_mode((WIDTH, HEIGHT)) # pygame lager en skjerm. 
        pg.display.set_caption("pygame mal") #Navn i headeren av vinduet
        self.running = True #Hvis true da kjører programmet. 
        self.aliensretning = 1
        self.level = 0
        self.liv = 3

        self.romskip = pg.sprite.Group() 
        self.skudd_sprites = pg.sprite.Group()
        self.aliens = pg.sprite.Group()
        self.aliensskudds = pg.sprite.Group()  
        self.shields = pg.sprite.Group()
        

        for y in range(6):
            hoyde = (HEIGHT - (HEIGHT/3)) + y*6
            for x in range(1,4):
                bredde = (WIDTH/4) * x
                for antall in range(1,8):
                    self.shield = Shield((bredde+(antall*6))-24,hoyde)
                    self.shields.add(self.shield)


        
    def start(self):
        self.level += 1
        Aliens.fart_x = abs(Aliens.fart_x) + 1
        Aliens.fart_y += 2
        Aliens.sjanse = int(Aliens.sjanse*0.9) 

        self.romskip.empty() 
        self.skudd_sprites.empty()
        self.aliens.empty()
        self.aliensskudds.empty()
        self.fly = Fly()
        self.romskip.add(self.fly)

            
        for x in range(1,7):
            bredde = (WIDTH/8) * x
            for y in range(1,4):
                hoyde = (HEIGHT/12) * y
                self.alien = Aliens(bredde,hoyde)
                self.aliens.add(self.alien)


    def alienskyt(self,x,y):
        x1 = x
        y1 = y
        self.aliensskudds.add(AliensPewPew(x1,y1))       
        
        
    def handle_events(self):
        for event in pg.event.get():
            if event.type == pg.QUIT: #hvis vi trykker på x øverst i vinduet da sluter programmet og animasjonen
                self.running = False #nå sluter dern 
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_SPACE and len(self.skudd_sprites) < 2:
                    self.skudd = PewPewFly(10)
                    self.skudd_sprites.add(self.skudd)

    def update(self):
        pg.sprite.groupcollide(
            self.skudd_sprites, self.aliens, True, True
            )
        
         
        pg.sprite.groupcollide(
            self.shields, self.aliensskudds, True, True
        )
        
        pg.sprite.groupcollide(
            self.shields, self.skudd_sprites, True, True
        )
        
        if pg.sprite.groupcollide(self.romskip, self.aliensskudds, False, True):
            self.liv -= 1
            if self.liv == 0:
                self.game_over()

        if pg.sprite.groupcollide(self.shields, self.aliens, False, False):
            self.game_over()
        elif pg.sprite.groupcollide(self.romskip, self.aliens, False, False):
           self.game_over()  


        self.romskip.update()  #viser alle tegninger bilder osv på skjermen, på sin riktige posisjon. 
        self.skudd_sprites.update()
        self.aliens.update()
        self.aliensskudds.update()
        self.shields.update()

    def game_over(self):
        self.draw_text(f"Du døde. Score: {self.level-1}", (WIDTH // 2, HEIGHT // 2), "red")
        pg.display.update()
        time.sleep(2)
        self.running = False
            
    def draw_text(self, text, pos, farge):
        font = pg.font.Font(None, 36)
        text_surface = font.render(text, True, farge)
        text_rect = text_surface.get_rect(center=pos)
        self.screen.blit(text_surface, text_rect)

    def draw(self):
        self.screen.fill("white")
        self.romskip.draw(self.screen) #tegner alle objekter men den er da ikke på skjermen ennå
        self.skudd_sprites.draw(self.screen)
        self.aliens.draw(self.screen)
        self.aliensskudds.draw(self.screen)
        self.shields.draw(self.screen)
        self.draw_text(f"Level: {self.level}", (50,50), "red")
        self.draw_text(f"Liv: {self.liv}", (WIDTH*(10/11),50), "green")
        
        
        pg.display.update() #nå kommer den på skjermen. 

        if len(self.aliens) == 0:
            self.draw_text(f"Du klarte level {self.level}", (WIDTH // 2, HEIGHT // 2, ), "green")
            pg.display.update()
            time.sleep(2)
            self.start()

        elif len(self.romskip) == 0:
            self.game_over()

    def run(self):
        forste = True
        while self.running == True: #så lenge den er True
            if forste == True:
                self.start()
                forste = False 

            self.handle_events()   # ser på x in vinduet men kan også se taster kolisjon osv
            self.update()#v == Fiser det riktige på skjermen. 
            self.draw() # tegner på skjermen, men viser det nye ikke
            self.clock.tick(FPS) #klokken som tikker i 24 FPS
        pg.quit() # self.running er nå False. 

if __name__ == "__main__": #Hvis jeg kjører den filen da blir den funksjonen brukt, hvis jeg arver av den da blir den ikke brukt. 
    app = App()
    app.run()