import pygame as pg
from pygame.locals import *
import os, sys
import random

WIDTH, HEIGHT = 400, 600
FPS = 30


class Spiller(pg.sprite.Sprite):
    fartretning = "down"
    def __init__(self) -> None:
        super().__init__()
        self.image = pg.Surface((20,20))
        self.image.fill("blue")
        # self.side = 30
        # url_bilde = "bilder/RumpelstiltskinShrek.png"
        # self.image = pg.image.load(os.path.join(sys.path[0], url_bilde)).convert_alpha()
        # self.image = pg.transform.scale(self.image, (self.side,self.side))
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = 100
        
        self.fart = 5
        

    def update(self):
        keys = pg.key.get_pressed()
        
        if keys[pg.K_a]: 
            Spiller.fartretning = "left"
        
        if keys[pg.K_d]:
            Spiller.fartretning = "right"
            
        if keys[pg.K_w]:
            Spiller.fartretning = "up"
            
        if keys[pg.K_s]:
            Spiller.fartretning = "down"
        #Bestemmer retningen spilleren/trollet beveger seg i
        
        if Spiller.fartretning == "left":
            self.rect.x -= self.fart
        elif Spiller.fartretning == "right":
            self.rect.x += self.fart
        elif Spiller.fartretning == "up":
            self.rect.y -= self.fart
        elif Spiller.fartretning == "down":
            self.rect.y += self.fart
            
        #Bør være greit å skjønne, hvis fartsretningenfor eksempel er "left", beveger den seg mot venstre
        
        if self.rect.left < 0:
            app.game_over = True
            self.kill()   #"kill()"Fjerner spilleren fra sprite gruppen
        elif self.rect.right > WIDTH:
            app.game_over = True
            self.kill()    
        elif self.rect.top < 0:
            app.game_over = True
            self.kill()    
        elif self.rect.bottom > HEIGHT:
            app.game_over = True
            self.kill()            
        #Sørger for at spillet avsluttes når spilleren havner utenfor spillet


class Matbit(pg.sprite.Sprite):
    def __init__(self, x, y) -> None:
        super().__init__()
        self.image = pg.Surface((40, 40))
        self.rect = self.image.get_rect()
        self.image.fill("yellow")
        self.rect.x = x
        self.rect.y = y
        #namnam

class Hinder(pg.sprite.Sprite):
    def __init__(self) -> None:
        super().__init__()
        self.image = pg.Surface((40, 40))
        self.rect = self.image.get_rect()
        self.image.fill("black")
        self.rect.x = 0
        self.rect.y = 0
        #au
    
    def bytt(self,spillobjekt): #denne funksjonen gjør slik at når spilleren treffer et godteri, bytter spilleren retning. Den "spretter" vekk fra godteriet etter det blit gjort om til hinder slik at spiller ikke dør av hinderet
        self.rect.x = spillobjekt.rect.x
        self.rect.y = spillobjekt.rect.y
        
        if Spiller.fartretning == "left":
            Spiller.fartretning = "right"
            
        elif Spiller.fartretning == "right":
            Spiller.fartretning = "left"
            
        elif Spiller.fartretning == "up":
            Spiller.fartretning = "down"
            
        elif Spiller.fartretning == "down":
            Spiller.fartretning = "up"


class App:
    def __init__(self):
        pg.init()
        self.clock = pg.time.Clock()
        self.screen = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption("pygame mal")
        self.running = True
        self.score = 0
        self.game_over = False
        self.spiller = pg.sprite.Group()
        self.hinder = pg.sprite.Group()
        self.matbit = pg.sprite.Group()
        self.midlertidigsprite = pg.sprite.Group()
        
        self.spiller.add(Spiller())
        
        for i in range(3):
            self.lag_matbit()
    
    
    def finn_kordinater(self): #Bestemmer hvor objektene skal spawne
        x,y = random.randint(40,WIDTH-40), random.randint(0,HEIGHT - 60)
        return x,y
    
    
    def finn_plassering(self,objekt): #Plasserer objektet på skjermen, hvis det allerede står et objekt der fra før, returnerer funksjonen False
        self.midlertidigsprite.add(objekt)
        
        if pg.sprite.groupcollide(self.midlertidigsprite, self.matbit, False, False) or pg.sprite.groupcollide(self.midlertidigsprite, self.hinder, False, False) or pg.sprite.groupcollide(self.midlertidigsprite, self.spiller, False, False):
            self.midlertidigsprite.empty()
            return False
        else:
            self.midlertidigsprite.empty()
            return True

    
    def lag_matbit(self): #Denne funksjonen lager matbitene, og sørger for at de ikke spawner oppå andre objekter
        riktigplassering = False
        while riktigplassering == False: #Blir kjørt helt til matbiten finner en ledig plass
            x,y = self.finn_kordinater()
            matbit = Matbit(x,y)
            funnetplassering = self.finn_plassering(matbit) #Blir enten False eller True
            if funnetplassering == True:
                self.matbit.add(matbit)
                riktigplassering = True

    def handle_events(self):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                self.running = False
        
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_SPACE and self.game_over == True:
                    self.restart()

    def update(self):
        if pg.sprite.groupcollide(self.spiller, self.hinder, True, False):
            self.game_over = True
            
        hits=(pg.sprite.groupcollide(self.spiller, self.matbit, False, True))
        for spillere, matbiter in hits.items(): #Vet ikke hva som skjer her
            for matbit in matbiter:
                hinder = Hinder()
                
                hinder.bytt(matbit)
                self.hinder.add(hinder)
                self.lag_matbit()
                
                self.score += 1
                
        self.spiller.update()
        self.matbit.update()
        self.hinder.update()
    
    def restart(self):
        self.matbit.empty()
        self.hinder.empty()
        self.score = 0
        self.spiller.add(Spiller())
        for i in range(3):
            self.lag_matbit()
            
        self.game_over = False
    
    def draw_text(self, text, pos, farge):
        font = pg.font.Font(None, 36)
        text_surface = font.render(text, True, farge)
        text_rect = text_surface.get_rect(center=pos)
        self.screen.blit(text_surface, text_rect)

    def draw(self):
        self.screen.fill("white")
        self.spiller.draw(self.screen)
        self.matbit.draw(self.screen)
        self.hinder.draw(self.screen)
        
        if self.game_over == True:
            self.draw_text(f"Du døde. Score: {self.score}", (WIDTH // 2, HEIGHT // 2), "red")
            self.draw_text(f"Trykk 'space' for å spille igjen:", (WIDTH // 2, HEIGHT // 1.5), "red")


        self.draw_text(f"Score: {self.score}", (50,50), "green")
        
        pg.display.update()

    def run(self):
        while self.running:
            self.handle_events()
            self.update()
            self.draw()
            self.clock.tick(FPS)
        pg.quit()


if __name__ == "__main__":
    app = App()
    app.run()
